import React from "react";
import StarRateIcon from "@mui/icons-material/StarRate";
import StarOutlineIcon from "@mui/icons-material/StarOutline";
const Card = () => {
  return (
    <div className="flex flex-col lg:flex-row justify-around p-6 lg:p-9">
      <div className="mx-4 lg:mx-8 mb-8 lg:mb-0">
        <h1 className="text-emerald-900 font-bold text-center lg:text-left">
          Testimonial
        </h1>
        <h1 className="text-3xl lg:text-5xl font-bold text-black text-center lg:text-left mt-4 lg:mt-0">
          What Our Clients <br />
          Say About Us
        </h1>
        <h1 className="pt-5 text-center lg:text-left">
          Let your hairdressers do their amazing job. Trim the{" "}
          <br className="hidden lg:block" />
          hair to get your desired look. Book an appointment with{" "}
          <br className="hidden lg:block" />
          us for your favorite hair styles!
        </h1>
        <div className="flex justify-center lg:justify-start">
          <button className="mt-7 bg-emerald-900 w-32 h-10 text-white">
            Give Reviews
          </button>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-10">
        <div className="w-full lg:w-72 bg-white flex flex-col items-center shadow-xl shadow-inner p-6">
          <img
            src="https://th.bing.com/th/id/OIP.6l05EpdB_uREO0KHAijauwAAAA?w=418&h=626&rs=1&pid=ImgDetMain"
            alt="Testimonial Image"
            className="w-24 h-24 rounded-full"
          />
          <h2 className="text-sm text-gray-300 font-bold pt-5 text-center">
            It was an amazing experience to get <br />
            services from the best in its profession. <br />
            Absolutely enjoyed every second of it.
          </h2>
          <p className="text-center pt-5">
            <StarRateIcon className="text-emerald-900" />{" "}
            <StarRateIcon className="text-emerald-900" />
            <StarRateIcon className="text-emerald-900" />
            <StarOutlineIcon />
            <StarOutlineIcon />
          </p>
          <p className="font-bold">Umar Usman</p>
          <p className="text-gray-300 font-bold">Regular User</p>
        </div>

        <div className="w-full lg:w-72 bg-white flex flex-col items-center shadow-xl shadow-inner p-6">
          <img
            src="https://th.bing.com/th/id/OIP.6l05EpdB_uREO0KHAijauwAAAA?w=418&h=626&rs=1&pid=ImgDetMain"
            alt="Testimonial Image"
            className="w-24 h-24 rounded-full"
          />
          <h2 className="text-sm text-gray-300 font-bold pt-5 text-center">
            It was an amazing experience to get <br />
            services from the best in its profession. <br />
            Absolutely enjoyed every second of it.
          </h2>
          <p className="text-center pt-5">
            <StarRateIcon className="text-emerald-900" />{" "}
            <StarRateIcon className="text-emerald-900" />
            <StarRateIcon className="text-emerald-900" />
            <StarOutlineIcon />
            <StarOutlineIcon />
          </p>
          <p className="font-bold">Rabia Khalil</p>
          <p className="text-gray-300 font-bold">Regular User</p>
        </div>
      </div>
    </div>
  );
};

export default Card;
