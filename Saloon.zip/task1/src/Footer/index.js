import React from "react";
import FacebookIcon from "@mui/icons-material/Facebook";
import InstagramIcon from "@mui/icons-material/Instagram";
import LinkedInIcon from "@mui/icons-material/LinkedIn";
import TwitterIcon from "@mui/icons-material/Twitter";

const Footer = () => {
  return (
    <div>
      <div className="gap-14 text-start w-full">
        <div>
          <div className="bg-black    text-white py-4 no">
            <div className=" mx-auto  flex justify-around items-center">
              <p className="text-sm ">Saloon</p>
              <div className="flex">
                <h1 className="mt-5">Ready To Get Started?</h1>
                <button className=" mx-7 mt-3 rounded-lg bg-emerald-900 w-28 h-10 text-white">
                  Give Reviews
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <footer className="bg-black text-white p-6 sm:p-10">
        <div className="max-w-screen-xl mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Logo and Subscribe */}
          <div className="space-y-4">
            <p className="text-xl text-center sm:text-left">
              Subscribe to our <br /> newsletter
            </p>
            <div className="flex justify-center sm:justify-start items-center mt-4">
              <input
                type="email"
                placeholder="Email address"
                className="p-2 rounded-l-md focus:outline-none"
              />
              <button className="bg-teal-600 p-2 rounded-r-md hover:bg-teal-700">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth="2"
                  stroke="currentColor"
                  className="w-5 h-6"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M5 12h14M12 5l7 7-7 7"
                  />
                </svg>
              </button>
            </div>
          </div>

          {/* Services Links */}
          <div className="space-y-2 text-center sm:text-left">
            <h4 className="font-semibold text-emerald-900">Services</h4>
            <ul className="space-y-1">
              <li>Email Marketing</li>
              <li>Campaigns</li>
              <li>Branding</li>
              <li>Offline</li>
            </ul>
          </div>

          {/* Company Links */}
          <div className="space-y-2 text-center sm:text-left">
            <h4 className="font-semibold text-emerald-900">About</h4>
            <ul className="space-y-1">
              <li>Our Story</li>
              <li>Benefits</li>
              <li>Team</li>
              <li>Careers</li>
            </ul>
          </div>

          {/* Support Links */}
          <div className="space-y-2 text-center sm:text-left">
            <h4 className="font-semibold text-emerald-900">Help</h4>
            <ul className="space-y-1">
              <li>FAQs</li>
              <li>Contact Us</li>
            </ul>
            {/* Social Media Icons */}
            <div className="flex justify-center sm:justify-start space-x-4 mt-4">
              <a href="#" aria-label="Facebook" className="hover:text-teal-400">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a href="#" aria-label="Twitter" className="hover:text-teal-400">
                <i className="fab fa-twitter"></i>
              </a>
              <a
                href="#"
                aria-label="Instagram"
                className="hover:text-teal-400"
              >
                <i className="fab fa-instagram"></i>
              </a>
            </div>
          </div>
        </div>
      </footer>

      <div className="gap-14 text-start w-full">
        <div className="bg-black    text-white py-4 no">
          <div className=" mx-auto  flex justify-around items-center">
            <p className="text-sm ">
              Term & Condition <span className="mx-4">Privacy & Policy</span>
            </p>
            <div>
              <a href="#" aria-label="Facebook">
                <FacebookIcon className="text-right" />
              </a>
              <a href="#" aria-label="Instagram " className="mx-2">
                <TwitterIcon />
              </a>
              <a href="#" aria-label="LinkedIn">
                <LinkedInIcon />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Footer;
