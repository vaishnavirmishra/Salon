import React from "react";

const WorkingDaysSection = () => {
  return (
    <div className=" text-start  h-96  mb-8 flex  overflow-hidden  justify-between lg:mx-[6.5rem] ">
      {/* Left Side: Image */}
      <div className="w-[400px]">
        <img
          src="/unsplash_wJoB8D3hnzc.png" // Replace with your image path
          alt="Barber at work"
          className="w-[450px] ml-32"
        />
      </div>

      {/* Right Side: Working Days Info */}
      <div className="w-1/2 h-96 mr-28 bg-gradient-to-r from-teal-800 to-teal-600 text-white py-12 px-10">
        <h2 className="text-3xl font-bold mb-4">WORKING DAYS</h2>
        <p className="mb-8 text-black">We are open on all six days in a week</p>

        <div className="mb-6 flex    ">
          <p className="font-semibold mr-4 ">Monday</p>

          <span className="ml-56 text-black">9AM to 10PM</span>
        </div>

        <div className="mb-6 flex ">
          <p className="font-semibold mr-4">Friday</p>
          <p className="ml-56 text-black">9AM to 10PM</p>
        </div>

        <button className="border border-black px-6 py-2  text-black rounded-md mt-4 hover:bg-white hover:text-teal-800">
          Book Now
        </button>
      </div>
    </div>
  );
};

export default WorkingDaysSection;
