import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./App.css";

import Footer from "./Footer";

import Navbar from "./Header1";
import AppointmentSection from "./Appoit";
import AppointmentSection1 from "./App";
import Haircutpage from "./Haircutpage";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/footer" element={<Footer />} />
        <Route path="/" element={<Navbar />} />
        <Route path="/appo" element={<AppointmentSection1 />} />

        <Route path="/appoit" element={<AppointmentSection />} />
        <Route path="/haircutpage" element={<Haircutpage />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
