import React from "react";
import LocalPhoneIcon from "@mui/icons-material/LocalPhone";
import StarRateIcon from "@mui/icons-material/StarRate";
import StarOutlineIcon from "@mui/icons-material/StarOutline";

const AppointmentSection = () => {
  return (
    <div className="pt-11 ">
      <div className="absolute">
        <img
          src="/Rectangle 7.png"
          alt=""
          className=" mx-7 lg:mx-0   w-96 lg:!w-[4500px]"
        />
      </div>
      <div className="relative top-0 lg:top-44  mx-10 lg:mx-7 font-bold  text-sm lg:text-4xl text-white">
        <h1>
          Book Your Appointment <br /> Online
        </h1>
        <p className="text-sm">
          Get 10% Discount On your First Hair <br /> Cut By Using Our Website
        </p>
        <button className=" mx-3 lg:mx-7 mt-7  text-sm bg-emerald-900   lg:w-36  lg:h-9 text-white">
          Book Appointment
        </button>
      </div>
      <div className=" relative lg:top-[10%] top-14 mx-20 lg:mx-[70%] w-60 h-56 bg-white flex flex-col items-center  shadow-xl shadow-inner">
        <img
          src="https://tse2.mm.bing.net/th?id=OIP.gC9BeUdwfC99nIkLvPXulwHaHw&pid=Api&P=0&h=180"
          alt="Job Search Made Easy"
          className="size-7  bg-slate-300 tw-mx-auto rounded-full mt-12 "
        />

        <p className="text-center text-gray-300 font-bold  mt-2 pt-5">
          Call Now
        </p>
        <p className="font-bold text-black mt-2">03007715325</p>
      </div>
    </div>
  );
};

export default AppointmentSection;
