import React from "react";
import ScissorsIcon from "@mui/icons-material/ContentCut"; // Assuming you use MUI icons for the scissor icon.
import AppointmentSection from "../Appoit";

import Card from "../Cardbox";
import Footer from "../Footer";
import Haircutpage from "../Haircutpage";

const Navbar = () => {
  return (
    <div>
      {" "}
      <div>
        {" "}
        <nav className="bg-black justify-around text-white p-5 py-4 px-8">
          <div className="container mx-auto flex flex-col md:flex-row justify-between items-center">
            {/* Left side: Logo */}
            <div className="flex items-center mb-4 md:mb-0">
              <span className="text-lg  pt-2 font-bold">HairHaven</span>
              <ScissorsIcon className="ml-2 pt-2" />
            </div>
            {/* Right side: Navigation links */}
            <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-8">
              <a
                href="#"
                className="text-sm pt-2 hover:text-gray-400 text-center md:text-left"
              >
                About Us
              </a>
              <a
                href="#"
                className="text-sm pt-2 hover:text-gray-400 text-center md:text-left"
              >
                Services
              </a>
              <a
                href="#"
                className="text-sm pt-2 hover:text-gray-400 text-center md:text-left"
              >
                Contact
              </a>
              <button className="bg-emerald-900 w-full md:w-28 h-9 text-white mx-auto md:mx-0">
                Give Reviews
              </button>
            </div>
          </div>
        </nav>
        <div className="relative">
          <div className="absolute w-full">
            <img src="/Frame 5.png" alt="" className="w-full h-auto" />
          </div>
          <div className="relative lg:top-44 top-9 px-6  lg:mx-28">
            <p className="text-sm text-center md:text-left text-emerald-900">
              Welcome To HairHaven
            </p>
            <h1 className="text-white text-sm lg:text-5xl font-bold text-center md:text-left">
              Best Hair Salon For A <br className="hidden md:block" />
              Professional Look
            </h1>
            <h1 className="text-white text-center md:text-left mt-4 md:mt-0">
              Choppers offers high performance{" "}
              <br className="hidden md:block" /> customized facials to provide
              you <br className="hidden md:block" />
              with visible results.
            </h1>
            <button className="mx-auto md:mx-0 md:ml-52 mt-7 bg-emerald-900 w-28 h-9 text-white block">
              All Services
            </button>
          </div>
        </div>
      </div>
      <div className=" pt-28 lg:pt-[43%]">
        <Haircutpage />
        <div />
        <div>
          <AppointmentSection />
        </div>
        <div className="mt-16  pt-7 lg:pt-28 h-auto flex flex-col lg:flex-row justify-between lg:mx-[6.5rem]">
          {/* Left Side: Image */}
          <div className="w-full lg:w-[498px] flex justify-center lg:justify-start">
            <img
              src="/unsplash_wJoB8D3hnzc.png" // Replace with your image path
              alt="Barber at work"
              className="w-[80%] lg:w-[450px] lg:ml-64 h-96"
            />
          </div>

          {/* Right Side: Working Days Info */}
          <div className=" w-96 lg:w-1/2 h-auto lg:h-96  mx-7 lg:mr-44 bg-emerald-900 text-white py-12 px-6  mt-14 lg:mt-0">
            <h2 className="text-2xl lg:text-3xl font-bold mb-4">
              WORKING DAYS
            </h2>
            <p className="mb-8 text-black">
              We are open on all six days in a week
            </p>

            <div className="mb-6 flex justify-between">
              <p className="font-semibold">Monday</p>
              <span className="text-black">9AM to 10PM</span>
            </div>

            <div className="mb-6 flex justify-between">
              <p className="font-semibold">Friday</p>
              <p className="text-black">9AM to 10PM</p>
            </div>

            <div className="flex justify-center lg:justify-start">
              <button className="border border-black px-6 py-2 text-black rounded-md mt-4 hover:bg-white hover:text-teal-800">
                Book Now
              </button>
            </div>
          </div>
        </div>
      </div>
      <div className="mt-11">
        {" "}
        <Card />
      </div>{" "}
      <div className="    lg:pt-11 ">
        <div className="absolute">
          <img
            src="/unsplash_NbtIDoFKGO8.png"
            alt=""
            className=" !w-[4500px]"
          />
        </div>
        <div className="relative top-7  lg:top-44 mx-[31%] font-bold  text-sm lg:text-3xl text-white">
          <h1>
            Join Us Become A Part Of Us By
            <br /> Becoming An Affiliate
          </h1>
        </div>
      </div>
      <div className="  pt-4 lg:pt-[25%]  lg:mt-16">
        {" "}
        <Footer />
      </div>{" "}
    </div>
  );
};

export default Navbar;
