import React from "react";

const Haircutpage = () => {
  return (
    <div className="flex flex-col md:flex-row p-2 mx-4 md:mx-8">
      <div className="flex justify-center md:w-1/2">
        <img src="/Designer.png" alt="" className="w-3/4 md:w-1/2" />
      </div>
      <div className="mt-4 md:mt-0 md:ml-8 md:w-1/2">
        <h1 className="text-emerald-900 text-center md:text-left">About Us</h1>
        <h1 className="text-2xl md:text-3xl text-black font-bold text-center md:text-left mt-2 md:mt-4">
          Find The Best Haircut Salon For Men
        </h1>
        <p className="text-center md:text-left mt-2">
          Let your hairdresser do their amazing job. Trim the hair to get your
          desired look. Book an appointment with us for your favorite hairstyle.
        </p>
        <div className="flex justify-center md:justify-start">
          <button className="mt-7 bg-emerald-900 w-28 h-10 text-white">
            Read More
          </button>
        </div>
      </div>
    </div>
  );
};

export default Haircutpage;
